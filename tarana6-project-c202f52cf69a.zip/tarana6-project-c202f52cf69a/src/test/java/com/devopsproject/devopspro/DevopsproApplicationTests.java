package com.devopsproject.devopspro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevopsproApplicationTests {

	@Test
	void contextLoads() {
	}

}
